import { Component, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  standalone:false
})
export class LoginComponent {
  email: string = '';
  password: string = '';
  errorMessage: string = '';

  constructor(@Inject(AuthService) private readonly authService: AuthService, private readonly router: Router) {}

  login() {
    this.authService.login(this.email, this.password).subscribe({
      next: (response) => {
        if (response.statusCode === 200) {
          localStorage.setItem('token', response.token); // Store JWT token
          this.router.navigate(['admin/create-employee']); // Redirect to home/dashboard
        } else {
          this.errorMessage = 'Invalid credentials';
        }
      },
      error: (error) => {
        this.errorMessage = 'Invalid credentials';
        console.error('Login error:', error);
      }
    });
  }
}