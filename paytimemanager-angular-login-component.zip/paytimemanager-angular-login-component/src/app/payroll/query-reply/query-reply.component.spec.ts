import { ComponentFixture, TestBed } from '@angular/core/testing';

import { QueryReplyComponent } from './query-reply.component';

describe('QueryReplyComponent', () => {
  let component: QueryReplyComponent;
  let fixture: ComponentFixture<QueryReplyComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [QueryReplyComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(QueryReplyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
