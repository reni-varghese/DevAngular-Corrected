import { Component } from '@angular/core';

@Component({
  selector: 'app-timesheet-approve',
  standalone: false,
  templateUrl: './timesheet-approve.component.html',
  styleUrl: './timesheet-approve.component.css'
})
export class TimesheetApproveComponent {

}
