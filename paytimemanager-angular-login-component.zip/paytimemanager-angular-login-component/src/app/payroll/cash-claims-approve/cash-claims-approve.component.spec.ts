import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CashClaimsApproveComponent } from './cash-claims-approve.component';

describe('CashClaimsApproveComponent', () => {
  let component: CashClaimsApproveComponent;
  let fixture: ComponentFixture<CashClaimsApproveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [CashClaimsApproveComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(CashClaimsApproveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
