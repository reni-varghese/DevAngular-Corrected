import { Component } from '@angular/core';

@Component({
  selector: 'app-add-timesheet',
  standalone: false,
  templateUrl: './add-timesheet.component.html',
  styleUrl: './add-timesheet.component.css'
})
export class AddTimesheetComponent {

}
