import { Component } from '@angular/core';

@Component({
  selector: 'app-add-query',
  standalone: false,
  templateUrl: './add-query.component.html',
  styleUrl: './add-query.component.css'
})
export class AddQueryComponent {

}
