import { Component } from '@angular/core';

@Component({
  selector: 'app-role-assign',
  standalone: false,
  templateUrl: './role-assign.component.html',
  styleUrl: './role-assign.component.css'
})
export class RoleAssignComponent {

}
