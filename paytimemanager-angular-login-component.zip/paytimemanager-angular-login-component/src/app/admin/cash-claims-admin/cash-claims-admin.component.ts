import { Component } from '@angular/core';

@Component({
  selector: 'app-cash-claims-admin',
  standalone: false,
  templateUrl: './cash-claims-admin.component.html',
  styleUrl: './cash-claims-admin.component.css'
})
export class CashClaimsAdminComponent {

}
