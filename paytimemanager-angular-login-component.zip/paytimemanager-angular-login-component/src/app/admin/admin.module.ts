import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreateEmployeeComponent } from './create-employee/create-employee.component';

import { ReactiveFormsModule } from '@angular/forms';
import { AdminDashboardComponent } from './admin-dashboard/admin-dashboard.component';
import { RoleAssignComponent } from './role-assign/role-assign.component';
import { TimesheetAdminComponent } from './timesheet-admin/timesheet-admin.component';
import { CashClaimsAdminComponent } from './cash-claims-admin/cash-claims-admin.component';
import { PayRateAdminComponent } from './pay-rate-admin/pay-rate-admin.component';


import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from "../shared/shared.module";
import { AdminComponent } from './admin/admin.component';


const adminRoutes: Routes = [
   
    
      { path: '', redirectTo: 'dashboard', pathMatch: 'full' }, // Default route
      { path: 'dashboard', component: AdminDashboardComponent },
      { path: 'create-employee', component: CreateEmployeeComponent },
      { path: 'cash-claims', component: CashClaimsAdminComponent },
      { path: 'payrate', component: PayRateAdminComponent },
      { path: 'role-assign', component: RoleAssignComponent },
      { path: 'timesheet', component: TimesheetAdminComponent },
   
];

@NgModule({
  declarations: [
    CreateEmployeeComponent,
    AdminDashboardComponent,
    RoleAssignComponent,
    TimesheetAdminComponent,
    CashClaimsAdminComponent,
    PayRateAdminComponent,
    AdminComponent
  ],
  imports: [
    CommonModule,
    ReactiveFormsModule,
    RouterModule.forChild(adminRoutes),
    SharedModule
],
  exports:[
    CreateEmployeeComponent
  ]
})
export class AdminModule { }
