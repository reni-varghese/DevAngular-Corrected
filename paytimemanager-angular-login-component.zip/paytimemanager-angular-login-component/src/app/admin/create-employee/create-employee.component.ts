import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-create-employee',
  standalone: false,
  templateUrl: './create-employee.component.html',
  styleUrl: './create-employee.component.css'
})
export class CreateEmployeeComponent {
  employeeForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.employeeForm = this.fb.group({
      name: ['', [Validators.required, Validators.pattern('[A-Za-z\\s]+')]],
      email: ['', [Validators.required, Validators.email]],
      dob: ['', Validators.required],
      bloodGroup: ['', Validators.required],
      gender: ['', Validators.required],
      maritalStatus: ['', Validators.required],
      aadharId: ['', [Validators.required, Validators.pattern('\\d{12}')]],
      phoneNumber: ['', [Validators.required, Validators.pattern('\\d{10}')]],
      role: ['', Validators.required],
      basicPay: ['', Validators.required],
      overtimePay: ['', Validators.required],
      nightShiftPay: ['', Validators.required],
      pensionFund: ['', Validators.required],
      hra: ['', Validators.required],
      lta: ['', Validators.required],
      mobileReimbursement: ['', Validators.required],
      foodReimbursement: ['', Validators.required],
      specialAllowance: ['', Validators.required],
      cashAllowance: ['', Validators.required],
      employeeNumber: [{ value: '', disabled: true }]
    });
  }

  ngOnInit(): void {
    // Additional initialization logic if needed
  }

  onSubmit(): void {
    if (this.employeeForm.valid) {
      const employeeData = this.employeeForm.getRawValue();
      console.log('Employee Data:', employeeData);
      // Handle form submission logic here
    }
  }
}
