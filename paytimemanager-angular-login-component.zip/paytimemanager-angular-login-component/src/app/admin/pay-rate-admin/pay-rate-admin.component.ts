import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-pay-rate-admin',
  standalone: false,
  templateUrl: './pay-rate-admin.component.html',
  styleUrls: ['./pay-rate-admin.component.css']
  
})
export class PayRateAdminComponent implements OnInit {
  payRatesForm!: FormGroup; // Use the non-null assertion operator

  constructor(private fb: FormBuilder) {}

  ngOnInit(): void {
    this.payRatesForm = this.fb.group({
      role: ['ProgramAnalystTrainee', Validators.required],
      basicPay: [{ value: '50000', disabled: true }, Validators.required],
      overtimePay: [{ value: '2000', disabled: true }, Validators.required],
      nightShiftPay: [{ value: '3000', disabled: true }, Validators.required],
      pensionFund: [{ value: '5000', disabled: true }, Validators.required],
      hra: [{ value: '10000', disabled: true }, Validators.required],
      lta: [{ value: '8000', disabled: true }, Validators.required],
      mobileReimbursement: [{ value: '1500', disabled: true }, Validators.required],
      foodReimbursement: [{ value: '2500', disabled: true }, Validators.required],
      specialAllowance: [{ value: '4000', disabled: true }, Validators.required],
      cashAllowance: [{ value: '3500', disabled: true }, Validators.required]
    });

    this.payRatesForm.get('role')!.valueChanges.subscribe(role => {
      this.fetchRoleData(role);
    });
  }

  onEdit(): void {
    Object.keys(this.payRatesForm.controls).forEach(control => {
      this.payRatesForm.get(control)!.enable();
    });
  }

  onSubmit(): void {
    if (this.payRatesForm.valid) {
      console.log(this.payRatesForm.value);
    }
  }

  fetchRoleData(role: string): void {
    // Random initialization for demonstration purposes
    const data = [
      {
        ProgramAnalystTrainee: {
          basicPay: '50000',
          overtimePay: '2000',
          nightShiftPay: '3000',
          pensionFund: '5000',
          hra: '10000',
          lta: '8000',
          mobileReimbursement: '1500',
          foodReimbursement: '2500',
          specialAllowance: '4000',
          cashAllowance: '3500'
        },
        SrDeveloper: {
          basicPay: '70000',
          overtimePay: '3000',
          nightShiftPay: '4000',
          pensionFund: '7000',
          hra: '15000',
          lta: '10000',
          mobileReimbursement: '2000',
          foodReimbursement: '3000',
          specialAllowance: '5000',
          cashAllowance: '4500'
        }
      }
    ];

    let selectedRole = role === 'ProgramAnalystTrainee' ? data[0].ProgramAnalystTrainee : data[0].SrDeveloper;
    this.payRatesForm.patchValue({
      basicPay: selectedRole.basicPay,
      overtimePay: selectedRole.overtimePay,
      nightShiftPay: selectedRole.nightShiftPay,
      pensionFund: selectedRole.pensionFund,
      hra: selectedRole.hra,
      lta: selectedRole.lta,
      mobileReimbursement: selectedRole.mobileReimbursement,
      foodReimbursement: selectedRole.foodReimbursement,
      specialAllowance: selectedRole.specialAllowance,
      cashAllowance: selectedRole.cashAllowance
    });
  }
}