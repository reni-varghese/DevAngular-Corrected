import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PayRateAdminComponent } from './pay-rate-admin.component';

describe('PayRateAdminComponent', () => {
  let component: PayRateAdminComponent;
  let fixture: ComponentFixture<PayRateAdminComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [PayRateAdminComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PayRateAdminComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
