package com.ptm.services;

import com.ptm.dto.CashClaimsAndAllowanceDTO;
import com.ptm.models.CashClaimsAndAllowance;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.time.LocalDate;
import java.util.List;


public interface ICashClaimsAndAllowanceService {
    List<CashClaimsAndAllowanceDTO> getAllClaims();
    CashClaimsAndAllowanceDTO getClaimById(int id);
    CashClaimsAndAllowance saveClaim(CashClaimsAndAllowance claim, MultipartFile file) throws IOException;

    byte[] getAttachmentByClaimId(int id);
    String updateRemark(int id, String remark);
    List<CashClaimsAndAllowance> findByEmpId(int empId);
    List<CashClaimsAndAllowanceDTO> findCashClaimForEmployeeBetweenDateRange(int empId, LocalDate startDate, LocalDate endDate);

}
