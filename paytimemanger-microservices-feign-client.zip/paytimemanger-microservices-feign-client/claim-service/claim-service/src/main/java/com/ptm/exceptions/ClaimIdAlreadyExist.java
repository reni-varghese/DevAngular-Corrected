package com.ptm.exceptions;

public class ClaimIdAlreadyExist extends RuntimeException {
    public ClaimIdAlreadyExist(String message) {
        super(message);
    }
}
