package com.ptm.exceptions;

public class ClaimAttachmentNotFound extends RuntimeException {
    public ClaimAttachmentNotFound(String message) {
        super(message);
    }
}


