package com.ptm.repositories;

import com.ptm.models.CashClaimsAndAllowance;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface CashClaimsAndAllowanceRepository extends JpaRepository<CashClaimsAndAllowance,Integer> {
    List<CashClaimsAndAllowance> findByEmpIdAndDateOfClaimBetween(int empId, LocalDate startDate, LocalDate endDate);
    List<CashClaimsAndAllowance> findByEmpId(int empId);
}

