package com.ptm.controllers;

import com.ptm.dto.CashClaimsAndAllowanceDTO;
import com.ptm.dto.responses.CustomResponse;
import com.ptm.models.CashClaimsAndAllowance;
import com.ptm.services.ICashClaimsAndAllowanceService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.patch;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@ExtendWith(MockitoExtension.class)
class CashClaimsAndAllowanceControllerTest {

    @Mock
    private ICashClaimsAndAllowanceService cashClaimsAndAllowanceService;

    @InjectMocks
    private CashClaimsAndAllowanceController cashClaimsAndAllowanceController;

    private MockMvc mockMvc;
    private CashClaimsAndAllowanceDTO cashClaimsAndAllowanceDTO;
    private CustomResponse customResponse;
    private CashClaimsAndAllowance cashClaimsAndAllowance;

    @BeforeEach
    void setUp() {
        mockMvc = MockMvcBuilders.standaloneSetup(cashClaimsAndAllowanceController).build();

        cashClaimsAndAllowanceDTO = new CashClaimsAndAllowanceDTO();
        cashClaimsAndAllowanceDTO.setClaimId(1);
        cashClaimsAndAllowanceDTO.setEmpId(1);
        cashClaimsAndAllowanceDTO.setEmpName("John Doe");
        cashClaimsAndAllowanceDTO.setDateOfClaim(LocalDate.now());
        cashClaimsAndAllowanceDTO.setDescription("Travel allowance for business trip");
        cashClaimsAndAllowanceDTO.setAttachment("Sample attachment".getBytes());
        cashClaimsAndAllowanceDTO.setAmount(100.0);
        cashClaimsAndAllowanceDTO.setRemark("Approved");
        cashClaimsAndAllowanceDTO.setDateOfAction(LocalDate.now().plusDays(1));
        cashClaimsAndAllowanceDTO.setAllowanceType("Travel");

        customResponse = new CustomResponse();
        customResponse.setStatusCode(HttpStatus.CREATED.value());
        customResponse.setMessage("Claim saved successfully");
        customResponse.setTimestamp(LocalDateTime.now());

        cashClaimsAndAllowance = new CashClaimsAndAllowance();
        cashClaimsAndAllowance.setClaim_id(1);
        cashClaimsAndAllowance.setEmpId(1);
        cashClaimsAndAllowance.setEmpName("John Doe");
        cashClaimsAndAllowance.setDateOfClaim(LocalDate.now());
        cashClaimsAndAllowance.setDescription("Travel allowance for business trip");
        cashClaimsAndAllowance.setAttachment("Sample attachment".getBytes());
        cashClaimsAndAllowance.setAmount(100.0);
        cashClaimsAndAllowance.setRemark("Approved");
        cashClaimsAndAllowance.setDateOfAction(LocalDate.now().plusDays(1));
        cashClaimsAndAllowance.setAllowanceType("Travel");
    }

    @Test
    void getAllClaims_success() throws Exception {
        when(cashClaimsAndAllowanceService.getAllClaims()).thenReturn(List.of(cashClaimsAndAllowanceDTO));

        mockMvc.perform(get("/api/claims"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$[0].claimId").value(1))
                .andExpect(jsonPath("$[0].empId").value(1))
                .andExpect(jsonPath("$[0].amount").value(100.0));

        verify(cashClaimsAndAllowanceService, times(1)).getAllClaims();

    }

    @Test
    void getClaimById_success() throws Exception {
        when(cashClaimsAndAllowanceService.getClaimById(1)).thenReturn(cashClaimsAndAllowanceDTO);

        mockMvc.perform(get("/api/claims/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.claimId").value(1))
                .andExpect(jsonPath("$.empId").value(1))
                .andExpect(jsonPath("$.amount").value(100.0));

        verify(cashClaimsAndAllowanceService, times(1)).getClaimById(1);
    }





    @Test
    void getAttachment_notFound() throws Exception {
        when(cashClaimsAndAllowanceService.getAttachmentByClaimId(1)).thenReturn(null);

        mockMvc.perform(get("/api/claims/attachment/1"))
                .andExpect(status().isNotFound());

        verify(cashClaimsAndAllowanceService, times(1)).getAttachmentByClaimId(1);
    }

    @Test
    void updateRemark_success() throws Exception {
        mockMvc.perform(patch("/api/claims/remark/1")
                        .contentType("application/json")
                        .content("{\"remark\":\"Updated Remark\"}"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("Remark updated successfully"));

        verify(cashClaimsAndAllowanceService, times(1)).updateRemark(eq(1), anyString());
    }

    @Test
    void findCashClaimForEmployeeBetweenDateRange_success() throws Exception {
        when(cashClaimsAndAllowanceService.findCashClaimForEmployeeBetweenDateRange(anyInt(), any(LocalDate.class), any(LocalDate.class)))
                .thenReturn(List.of(cashClaimsAndAllowanceDTO));

        mockMvc.perform(get("/api/claims/employee/1/date-range")
                        .param("startDate", "2023-01-01")
                        .param("endDate", "2023-12-31"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.length()").value(1))
                .andExpect(jsonPath("$[0].claimId").value(1))
                .andExpect(jsonPath("$[0].empId").value(1))
                .andExpect(jsonPath("$[0].amount").value(100.0));

        verify(cashClaimsAndAllowanceService, times(1)).findCashClaimForEmployeeBetweenDateRange(anyInt(), any(LocalDate.class), any(LocalDate.class));
    }
}
