package com.ptm.services;

import com.ptm.repositories.BlackListTokenRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class BlackListedTokenCleanupService {

    private final BlackListTokenRepository blackListTokenRepository;

    public BlackListedTokenCleanupService(BlackListTokenRepository blackListTokenRepository) {
        this.blackListTokenRepository = blackListTokenRepository;
    }

    @Scheduled(fixedRate = 600000)
    public void cleanUpExpiredTokens() {
        log.info("Cleaning up expired tokens.");
        blackListTokenRepository.deleteExpiredTokens();
        log.info("Expired tokens cleaned up at: {}", new java.util.Date());
    }
}
