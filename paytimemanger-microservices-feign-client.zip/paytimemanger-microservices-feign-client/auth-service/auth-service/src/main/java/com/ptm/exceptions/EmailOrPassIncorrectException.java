package com.ptm.exceptions;

public class EmailOrPassIncorrectException extends RuntimeException{
    public EmailOrPassIncorrectException() {
    }

    public EmailOrPassIncorrectException(String message) {
        super(message);
    }
}
