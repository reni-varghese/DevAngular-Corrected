package com.ptm.repositories;


import com.ptm.models.BlackListedToken;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.transaction.annotation.Transactional;

public interface BlackListTokenRepository extends JpaRepository<BlackListedToken, Long> {

    boolean existsByToken(String token);
    @Transactional
    @Modifying
    @Query("DELETE FROM BlackListedToken bt where bt.expirationTime <CURRENT_TIMESTAMP")
    void deleteExpiredTokens();
}
