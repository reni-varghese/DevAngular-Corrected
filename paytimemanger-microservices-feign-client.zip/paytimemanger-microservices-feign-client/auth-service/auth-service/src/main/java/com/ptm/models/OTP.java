package com.ptm.models;

import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Entity
@Table(name = "otps")
public class OTP {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long otpId;

    @Column(nullable = false)
    private Integer empId;

    @Column(nullable = false)
    private String otp;

    @Column(nullable = false)
    private LocalDateTime dateCreated;
}

