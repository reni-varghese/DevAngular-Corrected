package com.ptm.services;

import com.ptm.dtos.LoginDto;
import com.ptm.dtos.ResetPassDto;
import com.ptm.exceptions.EmailOrPassIncorrectException;
import com.ptm.exceptions.EmployeeNotFoundException;
import com.ptm.models.Employee;
import com.ptm.repositories.EmployeeRepository;
import com.ptm.security.JwtProvider;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class AuthServiceImpl implements AuthService {

    private final AuthenticationManager authenticationManager;
    private final EmployeeRepository employeeRepository;
    private final JwtProvider jwtProvider;
    private final PasswordEncoder passwordEncoder;

    public AuthServiceImpl(AuthenticationManager authenticationManager, EmployeeRepository employeeRepository, JwtProvider jwtProvider, PasswordEncoder passwordEncoder) {
        this.authenticationManager = authenticationManager;
        this.employeeRepository = employeeRepository;
        this.jwtProvider = jwtProvider;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    public String login(LoginDto loginDto) {
        log.info("Login attempt for user: {}", loginDto.getEmail());
        UsernamePasswordAuthenticationToken token = new UsernamePasswordAuthenticationToken(loginDto.getEmail(), loginDto.getPassword());
        Authentication authentication = authenticationManager.authenticate(token);
        SecurityContextHolder.getContext().setAuthentication(authentication);
        String jwtToken = jwtProvider.generateToken(authentication);
        log.info("User {} authenticated successfully.", loginDto.getEmail());
        return jwtToken;
    }

    @Override
    public String resetPassword(ResetPassDto resetPassDto, String email) {
        log.info("Password reset attempt for user: {}", email);
        Employee employee = employeeRepository.findByEmpEmail(email).orElseThrow(() -> new EmployeeNotFoundException("Employee Not Found"));

        if (employee.getEmpEmail().equalsIgnoreCase(resetPassDto.getEmail())) {
            if (passwordEncoder.matches(resetPassDto.getOldPassword(), employee.getPassword())) {
                employee.setPassword(passwordEncoder.encode(resetPassDto.getNewPassword()));
                log.info("Password reset successful for user: {}", email);
            } else {
                log.error("Incorrect password for user: {}", email);
                throw new EmailOrPassIncorrectException("Incorrect Password");
            }
        } else {
            log.error("Incorrect email provided for password reset: {}", email);
            throw new EmailOrPassIncorrectException("Incorrect Email");
        }

        employeeRepository.save(employee);
        return "Password Reset Successful";
    }
}
