package com.ptm.services;

import com.ptm.exceptions.InvalidOTPException;

public interface OTPService {
    String generateOtp(Integer empId);
    boolean validateOtp(Integer empId, String otp,String newPassword) throws InvalidOTPException;
    void updatePassword(Integer empId, String newPassword);
}

