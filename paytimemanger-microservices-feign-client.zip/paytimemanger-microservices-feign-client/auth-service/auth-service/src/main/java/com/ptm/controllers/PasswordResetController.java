package com.ptm.controllers;

import com.ptm.dtos.EmployeePasswordResetDTO;
import com.ptm.dtos.OTPDTO;
import com.ptm.dtos.responses.CustomResponse;
import com.ptm.exceptions.InvalidOTPException;
import com.ptm.models.Employee;
import com.ptm.repositories.EmployeeRepository;
import com.ptm.services.OTPService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;

@AllArgsConstructor
@RestController
@RequestMapping("/api/forgot-password")
@Slf4j
public class PasswordResetController {

    private final OTPService otpService;
    private final EmployeeRepository employeeRepository;

    @PostMapping("/send-otp")
    public ResponseEntity<CustomResponse> sendOtp(@RequestBody EmployeePasswordResetDTO employeePasswordResetDTO) {
        log.info("Sending OTP request for email: {}", employeePasswordResetDTO.getEmail());

        Employee employee = employeeRepository.findByEmpEmail(employeePasswordResetDTO.getEmail())
                .orElseThrow(() -> new UsernameNotFoundException("User Not Found"));

        otpService.generateOtp(employee.getEmpId());

        CustomResponse response = new CustomResponse(
                HttpStatus.OK.value(),
                "OTP sent successfully",
                LocalDateTime.now()
        );

        log.info("OTP sent successfully for employee ID: {}", employee.getEmpId());

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    @PatchMapping("/verify-otp")
    public ResponseEntity<CustomResponse> verifyOtp(@RequestBody OTPDTO otpDTO) throws InvalidOTPException {
        log.info("Verifying OTP for employee ID: {}", otpDTO.getEmpId());

        boolean isValid = otpService.validateOtp(otpDTO.getEmpId(), otpDTO.getOtp(), otpDTO.getNewPassword());

        CustomResponse response = new CustomResponse(
                isValid ? HttpStatus.OK.value() : HttpStatus.UNAUTHORIZED.value(),
                isValid ? "OTP verified successfully" : "Invalid OTP",
                LocalDateTime.now()
        );

        log.info(isValid ? "OTP verified successfully for employee ID: {}" : "Invalid OTP for employee ID: {}", otpDTO.getEmpId());

        return new ResponseEntity<>(response, isValid ? HttpStatus.OK : HttpStatus.UNAUTHORIZED);
    }
    @GetMapping
    public ResponseEntity<String> get()
    {
        String str="hi";
        return new ResponseEntity<>(str,HttpStatus.OK);
    }
}
