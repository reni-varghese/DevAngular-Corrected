package com.ptm.services;

import com.ptm.dtos.LoginDto;
import com.ptm.dtos.ResetPassDto;

public interface AuthService {

    String login(LoginDto loginDto);
    String resetPassword(ResetPassDto resetPassDto, String username);

}
