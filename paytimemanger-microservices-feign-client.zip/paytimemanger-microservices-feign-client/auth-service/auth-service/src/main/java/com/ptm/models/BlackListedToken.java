package com.ptm.models;

import jakarta.persistence.*;

import java.time.LocalDateTime;

@Entity
@Table(name="blacklist_token")
public class BlackListedToken {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    int id;
    @Column(nullable = false)
    private String token;

    @Column(name="expiration_time",nullable = false)
    private LocalDateTime expirationTime;


    public BlackListedToken() {
    }

    public BlackListedToken(int id, String token, LocalDateTime expirationTime) {
        this.id = id;
        this.token = token;
        this.expirationTime = expirationTime;

    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public LocalDateTime getExpirationTime() {
        return expirationTime;
    }

    public void setExpirationTime(LocalDateTime expirationTime) {
        this.expirationTime = expirationTime;
    }


}
