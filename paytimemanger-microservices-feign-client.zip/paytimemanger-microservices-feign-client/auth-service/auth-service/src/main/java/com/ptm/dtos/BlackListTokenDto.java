package com.ptm.dtos;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@NoArgsConstructor
@AllArgsConstructor
@Data
public class BlackListTokenDto {
    private String token;
    private LocalDateTime expirationTime;


}
