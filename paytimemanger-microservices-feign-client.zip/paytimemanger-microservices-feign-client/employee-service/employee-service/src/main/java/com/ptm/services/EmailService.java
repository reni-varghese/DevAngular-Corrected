package com.ptm.services;

import com.ptm.dto.EmployeeDTO;
import org.springframework.mail.MailException;

public interface EmailService {
    void sendOtpEmail(String to, String otp) throws MailException;
    void sendEmployeeDetailsEmail(EmployeeDTO employee) throws MailException;
}
