package com.ptm.dto;



import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.sql.Date;

@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class EmployeeDTO {
    private int empId;
    private String empName;
    private String empEmail;
    private Date empDob;
    private String empBloodGroup;
    private String empGender;
    private String empMaritalStatus;
    private String empNationalId;
    private String empPhoneNo;
    private String empRole;
    private boolean empActive;
    private boolean empIsPayroll;
    private Integer empPayrollManager;
    private String bankName;
    private String accountHolderName;
    private String accountNumber;
    private String ifscCode;
    private String branch;
    private String password;

}
