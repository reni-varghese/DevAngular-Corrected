package com.ptm.exceptions;

public class RoleAssignmentException extends RuntimeException{
    public RoleAssignmentException(String msg){
        super(msg);
    }
}
