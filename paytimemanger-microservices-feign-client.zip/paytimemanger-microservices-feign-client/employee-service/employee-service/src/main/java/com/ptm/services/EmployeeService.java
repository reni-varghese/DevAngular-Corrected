package com.ptm.services;

import com.ptm.dto.EmployeeDTO;
import com.ptm.dto.EmployeeNameDTO;
import com.ptm.exceptions.CustomResponse;
import com.ptm.models.Employee;

import java.util.List;

public interface EmployeeService {
    CustomResponse addEmployee(EmployeeDTO employeeDTO);
    EmployeeDTO getEmployeeById(int id);
    List<EmployeeDTO> getAll();
    EmployeeNameDTO getEmployeeNameByEmpId(int empId);
    List<Employee> findByEmpRoleNot();
}
