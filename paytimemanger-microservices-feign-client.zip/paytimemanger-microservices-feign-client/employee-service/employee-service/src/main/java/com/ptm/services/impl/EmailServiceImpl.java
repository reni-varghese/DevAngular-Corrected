package com.ptm.services.impl;

import com.ptm.dto.EmployeeDTO;
import com.ptm.exceptions.EmailSendingException;
import com.ptm.services.EmailService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
@AllArgsConstructor
@Slf4j

public class EmailServiceImpl implements EmailService {

    private final JavaMailSender mailSender;


    @Override
    public void sendOtpEmail(String to, String otp) {
        try {
            log.info("Sending OTP email to: {}", to);
            SimpleMailMessage message = new SimpleMailMessage();
            message.setTo(to);
            message.setSubject("Your OTP Code");
            message.setText("Your OTP code is " + otp + ". It is valid for 5 minutes.");

            mailSender.send(message);
            log.info("OTP email sent successfully to: {}", to);
        } catch (MailException e) {
            log.error("Error while sending OTP email to: {}", to, e);
            throw new EmailSendingException("Error while sending OTP email to " + to, e);
        }
    }

    @Override
    public void sendEmployeeDetailsEmail(EmployeeDTO employee) {
        try {
            String email = employee.getEmpEmail();
            String subject = "Your Employee Details";
            String message = "Dear " + employee.getEmpName() + ",\n\n" +
                    "Here are your employee details:\n" +
                    "ID: " + employee.getEmpId() + "\n" +
                    "Name: " + employee.getEmpName() + "\n" +
                    "Email: " + employee.getEmpEmail() + "\n" +
                    "DOB: " + employee.getEmpDob() + "\n" +
                    "Blood Group: " + employee.getEmpBloodGroup() + "\n" +
                    "Gender: " + employee.getEmpGender() + "\n" +
                    "Marital Status: " + employee.getEmpMaritalStatus() + "\n" +
                    "National ID: " + employee.getEmpNationalId() + "\n" +
                    "Phone No: " + employee.getEmpPhoneNo() + "\n" +
                    "Role: " + employee.getEmpRole() + "\n" +
                    "Bank Name: " + employee.getBankName() + "\n" +
                    "Account Holder Name: " + employee.getAccountHolderName() + "\n" +
                    "Account Number: " + employee.getAccountNumber() + "\n" +
                    "IFSC Code: " + employee.getIfscCode() + "\n" +
                    "Branch: " + employee.getBranch() + "\n\n" +
                    "Password: " + employee.getPassword() + "\n\n" +
                    "Please keep this information for your records.\n\n" +
                    "Best regards,\nThe HR Team";

            SimpleMailMessage mailMessage = new SimpleMailMessage();
            mailMessage.setTo(email);
            mailMessage.setSubject(subject);
            mailMessage.setText(message);

            mailSender.send(mailMessage);
            log.info("Employee details email sent successfully to: {}", email);
        } catch (MailException e) {
            log.error("Error while sending employee details email to: {}", employee.getEmpEmail(), e);
            throw new EmailSendingException("Error while sending email to " + employee.getEmpEmail(), e);
        }
    }
}
