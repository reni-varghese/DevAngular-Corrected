package com.ptm.services;

import com.ptm.services.impl.EmailServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class EmailServiceImplTest {

    @Mock
    private JavaMailSender mailSender;

    @InjectMocks
    private EmailServiceImpl emailService;

    private String to;
    private String otp;

    @BeforeEach
    public void setUp() {
        to = "test@example.com";
        otp = "123456";
    }

    @Test
    public void testSendOtpEmail_Success() {
        doNothing().when(mailSender).send(any(SimpleMailMessage.class));

        emailService.sendOtpEmail(to, otp);

        verify(mailSender, times(1)).send(any(SimpleMailMessage.class));
    }

    @Test
    public void testSendOtpEmail_MessageContent() {
        doAnswer(invocation -> {
            SimpleMailMessage message = invocation.getArgument(0);
            assertEquals(to, message.getTo()[0]);
            assertEquals("Your OTP Code", message.getSubject());
            assertEquals("Your OTP code is " + otp + ". It is valid for 5 minutes.", message.getText());
            return null;
        }).when(mailSender).send(any(SimpleMailMessage.class));

        emailService.sendOtpEmail(to, otp);

        verify(mailSender, times(1)).send(any(SimpleMailMessage.class));
    }

    @Test
    public void testSendOtpEmail_Exception() {
        doThrow(new RuntimeException("Mail server error")).when(mailSender).send(any(SimpleMailMessage.class));

        Exception exception = assertThrows(RuntimeException.class, () -> emailService.sendOtpEmail(to, otp));

        assertEquals("Mail server error", exception.getMessage());
        verify(mailSender, times(1)).send(any(SimpleMailMessage.class));
    }
}