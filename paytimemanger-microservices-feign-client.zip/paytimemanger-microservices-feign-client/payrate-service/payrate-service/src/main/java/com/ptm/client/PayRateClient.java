package com.ptm.client;

import com.ptm.dto.PayRateDTO;
import com.ptm.exceptions.CustomResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
@FeignClient(name = "PayRateClient", url = "${payRate.service.url}")
public interface PayRateClient {

    @PostMapping("/api/payRate")
    public ResponseEntity<CustomResponse> addPayRate(@RequestBody PayRateDTO payRateDTO);

    @GetMapping("/api/payRate")
    public ResponseEntity<List<PayRateDTO>> getAllPayRate();

    @GetMapping("/api/payRate/{id}")
    public ResponseEntity<PayRateDTO> getPayRateById(@PathVariable int id);

    @PatchMapping("/api/payRate/{id}")
    public ResponseEntity<PayRateDTO> partialUpdatePayRate(@PathVariable int id, @RequestBody Map<String, Object> updates);
}
