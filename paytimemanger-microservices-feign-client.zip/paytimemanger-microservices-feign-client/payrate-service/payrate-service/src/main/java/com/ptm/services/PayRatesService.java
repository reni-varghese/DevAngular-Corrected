package com.ptm.services;

import com.ptm.dto.PayRateDTO;
import com.ptm.exceptions.CustomResponse;
import com.ptm.models.PayRate;

import java.util.List;
import java.util.Map;
import java.util.Optional;

public interface PayRatesService {
    CustomResponse addPayRate(PayRateDTO payRateDTO);
    PayRateDTO getPayRateById(int id);
    List<PayRateDTO> getAllPayRate();
    PayRateDTO partialUpdatePayRate(int id, Map<String, Object> updates);
    Optional<PayRate> findByEmpRole(String empRole);
}
