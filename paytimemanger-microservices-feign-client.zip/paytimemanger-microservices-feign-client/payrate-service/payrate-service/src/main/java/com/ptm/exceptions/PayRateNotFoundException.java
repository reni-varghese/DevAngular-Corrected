package com.ptm.exceptions;

public class PayRateNotFoundException extends RuntimeException {
    public PayRateNotFoundException(String msg) {
        super(msg);
    }
}
