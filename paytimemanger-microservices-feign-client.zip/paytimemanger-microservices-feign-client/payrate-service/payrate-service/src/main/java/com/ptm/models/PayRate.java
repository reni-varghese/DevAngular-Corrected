package com.ptm.models;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
@Table(name = "pay_rate")
public class PayRate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "pay_rateid", nullable = false)
    private int payRateId;

    @Column(name = "emp_role", nullable = false)
    private String empRole;

    @Column(name = "Basic_Pay")
    private double basicPay;

    @Column(name = "Overtime_Pay")
    private double overtimePay;

    @Column(name = "PF")
    private double pf;

    @Column(name = "HRA")
    private double hra;



    @Column(name = "Mobile_Reimbursement")
    private double mobileReimbursement;

    @Column(name = "Food_Reimbursement")
    private double foodReimbursement;

    @Column(name = "Special_Allowance")
    private double specialAllowance;

    @Column(name = "Cash_Allowance")
    private double cashAllowance;
}
