package com.ptm.exceptions;

public class PayRateAlreadyExistsException extends RuntimeException {
    public PayRateAlreadyExistsException(String message) {
        super(message);
    }
}
