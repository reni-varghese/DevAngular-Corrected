package com.ptm.services;

import com.ptm.dto.PayRateDTO;
import com.ptm.exceptions.CustomResponse;
import com.ptm.exceptions.PayRateAlreadyExistsException;
import com.ptm.exceptions.PayRateNotFoundException;
import com.ptm.models.PayRate;
import com.ptm.repositories.PayRateRepository;
import com.ptm.services.impl.PayRatesServiceImpl;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class PayRatesServiceImplTest {

    @Mock
    private PayRateRepository payRateRepository;

    @InjectMocks
    private PayRatesServiceImpl payRatesService;

    private PayRateDTO payRateDTO;
    private PayRate payRate;

    @BeforeEach
    public void setUp() {
        payRateDTO = new PayRateDTO();
        payRateDTO.setPay_rateid(1);
        payRateDTO.setEmpRole("Developer");
        payRateDTO.setBasicPay(50000.0);
        payRateDTO.setOvertimePay(2000.0);
        payRateDTO.setPf(5000.0);
        payRateDTO.setHra(10000.0);
        payRateDTO.setMobileReimbursement(1000.0);
        payRateDTO.setFoodReimbursement(2000.0);
        payRateDTO.setSpecialAllowance(3000.0);
        payRateDTO.setCashAllowance(1500.0);

        payRate = new PayRate();
        payRate.setPayRateId(1);
        payRate.setEmpRole("Developer");
        payRate.setBasicPay(50000.0);
        payRate.setOvertimePay(2000.0);
        payRate.setPf(5000.0);
        payRate.setHra(10000.0);
        payRate.setMobileReimbursement(1000.0);
        payRate.setFoodReimbursement(2000.0);
        payRate.setSpecialAllowance(3000.0);
        payRate.setCashAllowance(1500.0);
    }

    @Test
    public void testAddPayRate_EmployeeAlreadyExists() {
        when(payRateRepository.existsById(1)).thenReturn(true);

        assertThrows(PayRateAlreadyExistsException.class, () -> payRatesService.addPayRate(payRateDTO));
    }

    @Test
    public void testAddPayRate_Success() {
        when(payRateRepository.existsById(1)).thenReturn(false);
        when(payRateRepository.save(any(PayRate.class))).thenReturn(payRate);

        CustomResponse response = payRatesService.addPayRate(payRateDTO);

        assertNotNull(response);
        assertEquals(HttpStatus.OK.value(), response.getStatusCode());
        assertEquals("PayRate with ID 1 is added successfully", response.getMessage());
        verify(payRateRepository, times(1)).save(any(PayRate.class));
    }

    @Test
    public void testGetPayRateById_PayRateNotFound() {
        when(payRateRepository.findById(1)).thenReturn(Optional.empty());

        assertThrows(PayRateNotFoundException.class, () -> payRatesService.getPayRateById(1));
    }

    @Test
    public void testGetPayRateById_Success() {
        when(payRateRepository.findById(1)).thenReturn(Optional.of(payRate));

        PayRateDTO result = payRatesService.getPayRateById(1);

        assertNotNull(result);
        assertEquals(payRate.getPayRateId(), result.getPay_rateid());
    }

    @Test
    public void testGetAllPayRate() {
        when(payRateRepository.findAll()).thenReturn(List.of(payRate));

        List<PayRateDTO> result = payRatesService.getAllPayRate();

        assertEquals(1, result.size());
        assertEquals(payRate.getPayRateId(), result.get(0).getPay_rateid());
    }

    @Test
    public void testPartialUpdatePayRate_PayRateNotFound() {
        when(payRateRepository.findById(1)).thenReturn(Optional.empty());

        assertThrows(PayRateNotFoundException.class, () -> payRatesService.partialUpdatePayRate(1, Collections.emptyMap()));
    }

    @Test
    public void testPartialUpdatePayRate_Success() {
        when(payRateRepository.findById(1)).thenReturn(Optional.of(payRate));
        when(payRateRepository.save(any(PayRate.class))).thenReturn(payRate);

        Map<String, Object> updates = Map.of("basicPay", 60000.0);

        PayRateDTO result = payRatesService.partialUpdatePayRate(1, updates);

        assertNotNull(result);
        assertEquals(60000.0, result.getBasicPay());
        verify(payRateRepository, times(1)).save(any(PayRate.class));
    }
}