package com.ptm.client;

import com.ptm.dto.ValidTokenResponse;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "auth-service")
public interface AuthClient {
    @GetMapping("/api/auth/validate/{token}")
    public ResponseEntity<ValidTokenResponse> validateToken(@PathVariable String token);
}
