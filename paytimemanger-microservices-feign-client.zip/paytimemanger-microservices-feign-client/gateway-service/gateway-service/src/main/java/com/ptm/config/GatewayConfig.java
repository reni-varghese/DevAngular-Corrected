package com.ptm.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayConfig {
    @Bean
    RouteLocator routeLocator(RouteLocatorBuilder builder)
    {
        return builder.routes()
                .route("employee-service", r->r.path("/api/employees/**")
                        .uri("lb://employee-service"))
                .route("claims-service",r->r.path("/api/claims/**")
                        .uri("lb://claim-service"))
                .route("auth-service",r->r.path("/api/auth/**")
                        .uri("lb://auth-service"))
                .route("payrate-service",r->r.path("/api/payRate/**")
                        .uri("lb://payrate-service"))
                .route("query-service",r->r.path("/api/query/**")
                        .uri("lb://query-service"))
                .route("salary-service",r->r.path("/api/salary/**")
                        .uri("lb://salary-service"))
                .build();


    }
}
