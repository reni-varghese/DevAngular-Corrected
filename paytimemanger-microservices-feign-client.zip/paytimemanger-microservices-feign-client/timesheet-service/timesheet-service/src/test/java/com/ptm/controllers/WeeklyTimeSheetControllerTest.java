package com.ptm.controllers;

import com.ptm.dto.requests.UpdateTimesheetDto;
import com.ptm.models.TimeSheet;
import com.ptm.models.WeeklyTimeSheet;
import com.ptm.services.WeeklyTimeSheetService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.sql.Time;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class WeeklyTimeSheetControllerTest {

    @Mock
    private WeeklyTimeSheetService weeklyTimeSheetImplementation;

    @InjectMocks
    private WeeklyTimeSheetController weeklyTimeSheetController;

    private WeeklyTimeSheet weeklyTimeSheet;
    private TimeSheet timeSheet;
    private UpdateTimesheetDto updateTimesheetDto;

    @BeforeEach
    void setUp() {
        weeklyTimeSheet = new WeeklyTimeSheet();
        timeSheet = new TimeSheet();
        updateTimesheetDto = new UpdateTimesheetDto();
        updateTimesheetDto.setHoursWorked(8.0);
        updateTimesheetDto.setOvertimeHours(2.0);
        updateTimesheetDto.setTopUpHours(1.0);
        updateTimesheetDto.setClockIn(Time.valueOf("09:00:00"));
        updateTimesheetDto.setClockOut(Time.valueOf("17:00:00"));
    }

    @Test
    void testGetSummary() {
        List<WeeklyTimeSheet> summaries = Arrays.asList(weeklyTimeSheet);
        when(weeklyTimeSheetImplementation.getAll()).thenReturn(summaries);

        List<WeeklyTimeSheet> response = weeklyTimeSheetController.getSummary();

        assertEquals(summaries, response);
        verify(weeklyTimeSheetImplementation, times(1)).getAll();
    }

    @Test
    void testGetTimesheet() {
        List<TimeSheet> timesheets = Arrays.asList(timeSheet);
        when(weeklyTimeSheetImplementation.getTimeSheetsFromMondayToCurrent(1, LocalDate.now())).thenReturn(timesheets);

        List<TimeSheet> response = weeklyTimeSheetController.getTimesheet(1, LocalDate.now());

        assertEquals(timesheets, response);
        verify(weeklyTimeSheetImplementation, times(1)).getTimeSheetsFromMondayToCurrent(1, LocalDate.now());
    }

    @Test
    void testAddWeekly() {
        when(weeklyTimeSheetImplementation.submitWeeklyTimeSheet(1, LocalDate.now())).thenReturn(weeklyTimeSheet);

        ResponseEntity<WeeklyTimeSheet> response = weeklyTimeSheetController.addWeekly(1, LocalDate.now());

        assertEquals(HttpStatus.CREATED, response.getStatusCode());
        assertEquals(weeklyTimeSheet, response.getBody());
        verify(weeklyTimeSheetImplementation, times(1)).submitWeeklyTimeSheet(1, LocalDate.now());
    }

    @Test
    void testUpdateTimesheet() {
        when(weeklyTimeSheetImplementation.onlyUpdateTimesheet(1, LocalDate.now(), updateTimesheetDto)).thenReturn(timeSheet);

        TimeSheet response = weeklyTimeSheetController.updateTimesheet(1, LocalDate.now(), updateTimesheetDto);

        assertEquals(timeSheet, response);
        verify(weeklyTimeSheetImplementation, times(1)).onlyUpdateTimesheet(1, LocalDate.now(), updateTimesheetDto);
    }

    @Test
    void testUpdate() {
        when(weeklyTimeSheetImplementation.updateTimesheet(1, LocalDate.now(), updateTimesheetDto)).thenReturn(timeSheet);

        TimeSheet response = weeklyTimeSheetController.update(1, LocalDate.now(), updateTimesheetDto);

        assertEquals(timeSheet, response);
        verify(weeklyTimeSheetImplementation, times(1)).updateTimesheet(1, LocalDate.now(), updateTimesheetDto);
    }
}