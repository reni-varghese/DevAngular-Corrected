package com.ptm.controllers;

import com.ptm.dto.TimesheetDto;
import com.ptm.dto.responses.SuccessCreation;
import com.ptm.exceptions.EmployeeNotFoundException;
import com.ptm.services.TimeSheetService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.sql.Time;
import java.time.LocalDate;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class TimeSheetControllerTest {

    @Mock
    private TimeSheetService timeSheetServiceImplementation;

    @InjectMocks
    private TimeSheetController timeSheetController;

    private TimesheetDto timesheetDto;
    private SuccessCreation successCreation;

    @BeforeEach
    void setUp() {
        timesheetDto = new TimesheetDto();
        timesheetDto.setEmpId(1);
        timesheetDto.setDate(LocalDate.now());
        timesheetDto.setClockIn(Time.valueOf("09:00:00"));
        timesheetDto.setClockOut(Time.valueOf("17:00:00"));
        timesheetDto.setTopUpHours(1.0);

        successCreation = new SuccessCreation("Timesheet added successfully", HttpStatus.OK.value());
    }

    @Test
    void testGetAllDetails() {
        List<TimesheetDto> timesheetList = Arrays.asList(timesheetDto);
        when(timeSheetServiceImplementation.getAll()).thenReturn(timesheetList);

        List<TimesheetDto> response = timeSheetController.getAllDetails();

        assertEquals(timesheetList, response);
        verify(timeSheetServiceImplementation, times(1)).getAll();
    }

    @Test
    void testGetDataById() {
        List<TimesheetDto> timesheetList = Arrays.asList(timesheetDto);
        when(timeSheetServiceImplementation.existsByEmpId(1)).thenReturn(true);
        when(timeSheetServiceImplementation.getById(1)).thenReturn(timesheetList);

        ResponseEntity<List<TimesheetDto>> response = timeSheetController.getDataById(1);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(timesheetList, response.getBody());
        verify(timeSheetServiceImplementation, times(1)).existsByEmpId(1);
        verify(timeSheetServiceImplementation, times(1)).getById(1);
    }

    @Test
    void testGetDataById_EmployeeNotFound() {
        when(timeSheetServiceImplementation.existsByEmpId(1)).thenReturn(false);

        assertThrows(EmployeeNotFoundException.class, () -> {
            timeSheetController.getDataById(1);
        });

        verify(timeSheetServiceImplementation, times(1)).existsByEmpId(1);
        verify(timeSheetServiceImplementation, times(0)).getById(anyInt());
    }

    @Test
    void testGetDataByIdAndDate() {
        List<TimesheetDto> timesheetList = Arrays.asList(timesheetDto);
        LocalDate from = LocalDate.now().minusDays(10);
        LocalDate to = LocalDate.now();
        when(timeSheetServiceImplementation.getByEmpIdAndDate(1, from, to)).thenReturn(timesheetList);

        List<TimesheetDto> response = timeSheetController.getDataByIdAndDate(1, from, to);

        assertEquals(timesheetList, response);
        verify(timeSheetServiceImplementation, times(1)).getByEmpIdAndDate(1, from, to);
    }

    @Test
    void testAddTimesheet() {
        when(timeSheetServiceImplementation.add(timesheetDto)).thenReturn(successCreation);

        SuccessCreation response = timeSheetController.addTimesheet(timesheetDto);

        assertEquals(successCreation, response);
        verify(timeSheetServiceImplementation, times(1)).add(timesheetDto);
    }
}