package com.ptm.models;

import jakarta.persistence.*;

import java.sql.Time;
import java.time.LocalDate;

@Entity
@Table(name="timesheet")
public class TimeSheet {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int Timesheet_ID;
    @Column(name="Emp_Id")
    private int empId;
    @Column(name="Date")
    private LocalDate date;

    private Time Clock_In;
    private Time Clock_Out;
    //@Column(name = "TopUp_Hours")
    private Double Topup_Hours;
    private Double Total_Hours;
    private Double Overtime_Hours;

    public Double getTotal_Hours() {
        return Total_Hours;
    }

    public void setTotal_Hours(Double total_Hours) {
        Total_Hours = total_Hours;
    }

    public Double getOvertime_Hours() {
        return Overtime_Hours;
    }

    public void setOvertime_Hours(Double overtime_Hours) {
        Overtime_Hours = overtime_Hours;
    }

    public int getTimesheet_ID() {
        return Timesheet_ID;
    }

    public void setTimesheet_ID(int timesheet_ID) {
        Timesheet_ID = timesheet_ID;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public Time getClock_In() {
        return Clock_In;
    }

    public void setClock_In(Time clock_In) {
        Clock_In = clock_In;
    }

    public Time getClock_Out() {
        return Clock_Out;
    }

    public void setClock_Out(Time clock_Out) {
        Clock_Out = clock_Out;
    }

    public Double getTopup_Hours() {
        return Topup_Hours;
    }

    public void setTopup_Hours(Double topup_Hours) {
        Topup_Hours = topup_Hours;
    }


}
