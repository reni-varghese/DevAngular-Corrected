package com.ptm.services.impl;

import com.ptm.dto.TimesheetDto;
import com.ptm.dto.requests.UpdateTimesheetDto;
import com.ptm.models.TimeSheet;
import com.ptm.models.WeeklyTimeSheet;
import com.ptm.exceptions.EmployeeNotFoundException;
import com.ptm.exceptions.ResourceNotFoundException;
import com.ptm.repositories.TimeSheetRepository;
import com.ptm.repositories.WeeklyTimeSheetRepository;
import com.ptm.services.TimeSheetService;
import com.ptm.services.WeeklyTimeSheetService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.temporal.TemporalAdjusters;
import java.util.List;

@Slf4j
@Service
public class WeeklyTimeSheetImpl implements WeeklyTimeSheetService {
    private TimeSheetService timeSheetService;
    private WeeklyTimeSheetRepository weeklyTimeSheetRepository;
    private TimeSheetRepository timeSheetRepository;

    public WeeklyTimeSheetImpl(WeeklyTimeSheetRepository weeklyTimeSheetRepository, TimeSheetService timeSheetService, TimeSheetRepository timeSheetRepository) {
        this.weeklyTimeSheetRepository = weeklyTimeSheetRepository;
        this.timeSheetService = timeSheetService;
        this.timeSheetRepository = timeSheetRepository;
    }

    @Override
    public List<WeeklyTimeSheet> getAll() {
        log.info("Fetching all weekly timesheets");
        return weeklyTimeSheetRepository.findAll();
    }

    @Override
    public List<TimeSheet> getTimeSheetsFromMondayToCurrent(int empId, LocalDate curr) {
        if (timeSheetService.existsByEmpId(empId) && weeklyTimeSheetRepository.existsByEmpId(empId)) {
            LocalDate weekStart = curr.with(DayOfWeek.MONDAY);
            List<TimesheetDto> li = timeSheetService.getByEmpIdAndDate(empId, weekStart, curr);
            List<TimeSheet> li2 = li.stream().map(this::convertToEntity).toList();
            log.info("Fetched timesheets from Monday to current date for employee id: {}", empId);
            return li2;
        }
        log.error("Timesheet of employee {} does not exist", empId);
        throw new EmployeeNotFoundException("Timesheet of employee " + empId + " does not exist");
    }

    // fetching data based on status
    public List<WeeklyTimeSheet> getPendingWeeklyTimesheets(String status) {
        if (status.equalsIgnoreCase("Pending") || status.equalsIgnoreCase("Approved") || status.equalsIgnoreCase("Rejected")) {
            log.info("Fetching weekly timesheets with status: {}", status);
            return weeklyTimeSheetRepository.getByStatus(status);
        }
        log.error("Timesheet data does not exist for status: {}", status);
        throw new ResourceNotFoundException("Timesheet data does not exist please Enter valid Inputs");
    }

    @Override
    public boolean existsByEmpId(int empId) {
        log.info("Checking if timesheet exists for employee id: {}", empId);
        return weeklyTimeSheetRepository.existsByEmpId(empId);
    }

    @Override
    public WeeklyTimeSheet submitWeeklyTimeSheet(int empId, LocalDate currentDate) {
        if (!timeSheetRepository.existsByEmpId(empId)) {
            log.error("Cannot submit timesheet for Employee ID: {}", empId);
            throw new EmployeeNotFoundException("You can't submit timesheet for Employee ID : " + empId);
        }
        LocalDate weekStart = currentDate.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY));
        LocalDate weekEnd = currentDate.with(TemporalAdjusters.nextOrSame(DayOfWeek.SUNDAY));


        List<TimeSheet> timeSheets = timeSheetRepository.getByEmpIdAndDateBetween(empId, weekStart, weekEnd);

        if (timeSheets == null || timeSheets.isEmpty()) {
            log.error("Timesheets from {} to {} do not exist", weekStart, weekEnd);
            throw new ResourceNotFoundException("Timesheets from: " + weekStart + " to " + weekEnd + " do not exist");

        }

        double totalHours = timeSheets.stream()
                .mapToDouble(ts -> {
                    Double hours = ts.getTotal_Hours();
                    return (hours != null) ? hours : 0.0;
                })
                .sum();

        double overtimeHours = timeSheets.stream()
                .mapToDouble(ts -> {
                    Double hours = ts.getOvertime_Hours();
                    return (hours != null) ? hours : 0.0;
                })
                .sum();

        WeeklyTimeSheet weeklyTimeSheet = new WeeklyTimeSheet();
        weeklyTimeSheet.setEmpId(empId);
        weeklyTimeSheet.setWeekStart(weekStart);
        weeklyTimeSheet.setWeekEnd(weekEnd);
        weeklyTimeSheet.setTotalHours(totalHours);
        weeklyTimeSheet.setOvertimeHours(overtimeHours);
        weeklyTimeSheet.setStatus("Pending");

        log.info("Submitting weekly timesheet for employee id: {}", empId);
        return weeklyTimeSheetRepository.save(weeklyTimeSheet);
    }

    // code for only updating timesheet
    @Override
    public TimeSheet onlyUpdateTimesheet(int id, LocalDate date, UpdateTimesheetDto updateTimesheetDTO) {
        TimeSheet timesheet = timeSheetService.findByEmpIdAndDate(id, date)
                .orElseThrow(() -> {
                    log.error("Timesheet not found for employee id: {}", id);
                    return new ResourceNotFoundException("Timesheet not found for this id :: " + id);
                });
        timesheet.setTopup_Hours(updateTimesheetDTO.getTopUpHours());
        timesheet.setTotal_Hours(updateTimesheetDTO.getHoursWorked());
        timesheet.setOvertime_Hours(updateTimesheetDTO.getOvertimeHours());
        timesheet.setClock_In(updateTimesheetDTO.getClockIn());
        timesheet.setClock_Out(updateTimesheetDTO.getClockOut());
        log.info("Updating timesheet for employee id: {}", id);
        timeSheetRepository.save(timesheet);
        return timesheet;
    }

    // code for updating timesheet and weeklyTimesheet
    @Override
    public TimeSheet updateTimesheet(int id, LocalDate date, UpdateTimesheetDto updateTimesheetDTO) {
        TimeSheet timesheet = timeSheetService.findByEmpIdAndDate(id, date)
                .orElseThrow(() -> {
                    log.error("Timesheet not found for employee id: {} while updating timesheet and weekly timesheet", id);
                    return new ResourceNotFoundException("Timesheet not found for this id :: " + id);
                });
        timesheet.setTopup_Hours(updateTimesheetDTO.getTopUpHours());
        timesheet.setTotal_Hours(updateTimesheetDTO.getHoursWorked());
        timesheet.setOvertime_Hours(updateTimesheetDTO.getOvertimeHours());
        timesheet.setClock_In(updateTimesheetDTO.getClockIn());
        timesheet.setClock_Out(updateTimesheetDTO.getClockOut());
        timeSheetRepository.save(timesheet);

        updateWeeklyTimesheet(timesheet);
        log.info("Updating timesheet and weekly timesheet for employee id: {}", id);
        return timesheet;
    }

    private void updateWeeklyTimesheet(TimeSheet timesheet) {
        int empId = timesheet.getEmpId();
        if (!timeSheetRepository.existsByEmpId(empId)) {
            log.error("Employee not found for id: {}", empId);
            throw new ResourceNotFoundException("Employee not found for this id :: " + empId);
        }

        LocalDate weekStartDate = timesheet.getDate().with(DayOfWeek.MONDAY);
        WeeklyTimeSheet weeklyTimesheet = weeklyTimeSheetRepository.findByEmpIdAndWeekStartDate(empId, weekStartDate)
                .orElse(new WeeklyTimeSheet());

        weeklyTimesheet.setEmpId(empId);
        weeklyTimesheet.setWeekStart(weekStartDate);
        Double totalHours = calculateTotalHours(empId, weekStartDate);
        Double TotalOverTimeHours = calculateTotalOvertimeHours(empId, weekStartDate);
        weeklyTimesheet.setTotalHours(totalHours);
        weeklyTimesheet.setOvertimeHours(TotalOverTimeHours);
        if (totalHours > 50.0) {
            weeklyTimesheet.setStatus("Approved");
        } else {
            weeklyTimesheet.setStatus("Rejected");
        }

        log.info("Updating weekly timesheet for employee id: {}", empId);
        weeklyTimeSheetRepository.save(weeklyTimesheet);
    }

    private Double calculateTotalHours(int empId, LocalDate weekStartDate) {
        log.info("Calculating total hours for employee id: {} for the week starting on: {}", empId, weekStartDate);
        LocalDateTime weekStartDateTime = weekStartDate.atStartOfDay();
        LocalDateTime weekEndDateTime = weekStartDate.plusDays(6).atTime(LocalTime.MAX);
        Double totalHours = timeSheetRepository.getByEmpIdAndDateBetween(empId, weekStartDateTime.toLocalDate(), weekEndDateTime.toLocalDate())
                .stream()
                .mapToDouble(TimeSheet::getTotal_Hours)
                .sum();
        log.info("Total hours calculated: {}", totalHours);
        return totalHours;
    }


    private Double calculateTotalOvertimeHours(int empId, LocalDate weekStartDate) {
        log.info("Calculating total overtime hours for employee id: {} for the week starting on: {}", empId, weekStartDate);
        LocalDateTime weekStartDateTime = weekStartDate.atStartOfDay();
        LocalDateTime weekEndDateTime = weekStartDate.plusDays(6).atTime(LocalTime.MAX);
        Double totalOvertimeHours = timeSheetRepository.getByEmpIdAndDateBetween(empId, weekStartDateTime.toLocalDate(), weekEndDateTime.toLocalDate())
                .stream()
                .mapToDouble(TimeSheet::getOvertime_Hours)
                .sum();
        log.info("Total overtime hours calculated: {}", totalOvertimeHours);
        return totalOvertimeHours;
    }

    private TimeSheet convertToEntity(TimesheetDto dto) {
        log.info("Converting TimesheetDto to TimeSheet entity for employee id: {}", dto.getEmpId());
        TimeSheet timesheet = new TimeSheet();
        timesheet.setEmpId(dto.getEmpId());
        timesheet.setDate(dto.getDate());
        timesheet.setClock_In(dto.getClockIn());
        timesheet.setClock_Out(dto.getClockOut());
        timesheet.setTopup_Hours(dto.getTopUpHours());
        log.info("Timesheet entity created: {}", timesheet);
        return timesheet;
    }

    @Override
    public List<WeeklyTimeSheet> findByEmpIdAndStatus(int empId, String status) {
        return weeklyTimeSheetRepository.findByEmpIdAndStatus(empId, status);
    }

}

