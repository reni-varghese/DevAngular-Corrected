package com.ptm.controllers;
import com.ptm.dto.requests.UpdateTimesheetDto;
import com.ptm.models.TimeSheet;
import com.ptm.models.WeeklyTimeSheet;
import com.ptm.services.WeeklyTimeSheetService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/weekly-summary")
@Slf4j
public class WeeklyTimeSheetController {

    private final WeeklyTimeSheetService weeklyTimeSheetImplementation;

    public WeeklyTimeSheetController(WeeklyTimeSheetService weeklyTimeSheetImplementation){
        this.weeklyTimeSheetImplementation = weeklyTimeSheetImplementation;
    }
    @GetMapping("/salary-timesheets")
    public List<WeeklyTimeSheet> findByEmpIdAndStatus(@RequestParam int empId, @RequestParam String status) {
        return weeklyTimeSheetImplementation.findByEmpIdAndStatus(empId, status);
    }

    @GetMapping
    public List<WeeklyTimeSheet> getSummary(){
        log.info("Fetching all weekly timesheet summaries.");
        List<WeeklyTimeSheet> summaries = weeklyTimeSheetImplementation.getAll();
        log.info("Weekly timesheet summaries retrieved: {}", summaries);
        return summaries;
    }

    @GetMapping("/id/{empId}/date/{date}")
    public List<TimeSheet> getTimesheet(@PathVariable int empId, @PathVariable LocalDate date){
        log.info("Fetching timesheet for employee ID: {} on date: {}", empId, date);
        List<TimeSheet> timesheets = weeklyTimeSheetImplementation.getTimeSheetsFromMondayToCurrent(empId, date);
        log.info("Timesheets for employee ID: {} on date: {} retrieved: {}", empId, date, timesheets);
        return timesheets;
    }

    @PostMapping("/{empId}/{currentDate}")
    public ResponseEntity<WeeklyTimeSheet> addWeekly(@PathVariable int empId, @PathVariable LocalDate currentDate){
        log.info("Submitting weekly timesheet for employee ID: {} on date: {}", empId, currentDate);
        WeeklyTimeSheet weeklyTimeSheet = weeklyTimeSheetImplementation.submitWeeklyTimeSheet(empId, currentDate);
        log.info("Weekly timesheet for employee ID: {} on date: {} submitted successfully.", empId, currentDate);
        return new ResponseEntity<>(weeklyTimeSheet, HttpStatus.CREATED);
    }

    // Updating timesheet
    @PatchMapping("timesheet/id/{empId}/date/{date}")
    public TimeSheet updateTimesheet(@PathVariable int empId, @PathVariable LocalDate date, @RequestBody UpdateTimesheetDto updateTimesheetDto){
        log.info("Updating timesheet for employee ID: {} on date: {} with data: {}", empId, date, updateTimesheetDto);
        TimeSheet updatedTimesheet = weeklyTimeSheetImplementation.onlyUpdateTimesheet(empId, date, updateTimesheetDto);
        log.info("Timesheet for employee ID: {} on date: {} updated successfully.", empId, date);
        return updatedTimesheet;
    }

    // Updating timesheet and reflecting it on weeklyTimesheet
    @PatchMapping("/id/{empId}/date/{date}")
    public TimeSheet update(@PathVariable int empId, @PathVariable LocalDate date, @RequestBody UpdateTimesheetDto updateTimesheetDto){
        log.info("Updating timesheet and reflecting on weekly timesheet for employee ID: {} on date: {} with data: {}", empId, date, updateTimesheetDto);
        TimeSheet updatedTimesheet = weeklyTimeSheetImplementation.updateTimesheet(empId, date, updateTimesheetDto);
        log.info("Timesheet for employee ID: {} on date: {} updated and reflected on weekly timesheet successfully.", empId, date);
        return updatedTimesheet;
    }
}

