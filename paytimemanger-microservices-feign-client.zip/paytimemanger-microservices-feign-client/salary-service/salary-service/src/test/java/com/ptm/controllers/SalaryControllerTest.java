package com.ptm.controllers;

import com.ptm.dto.requests.SalaryCalculationRequestDTO;
import com.ptm.dto.responses.CustomResponse;
import com.ptm.dto.responses.SalaryDTO;
import com.ptm.models.Salary;
import com.ptm.services.ISalaryCalculationService;
import com.ptm.services.SalaryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.YearMonth;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class SalaryControllerTest {

    @Mock
    private SalaryService salaryService;

    @Mock
    private ISalaryCalculationService salaryCalculationService;

    @InjectMocks
    private SalaryController salaryController;

    private Salary salary;
    private SalaryDTO salaryDTO;
    private SalaryCalculationRequestDTO request;
    private CustomResponse customResponse;

    @BeforeEach
    void setUp() {
        salary = new Salary();
        salaryDTO = new SalaryDTO(
                1, 1, LocalDate.now(), 50000.0, 2000.0, 1000.0, 51000.0, "John Doe", LocalDate.now()
        );

        request = new SalaryCalculationRequestDTO();
        request.setMonthYear(YearMonth.parse("2025-01"));

        customResponse = new CustomResponse(
                HttpStatus.OK.value(),
                "Salaries calculated and stored successfully",
                LocalDateTime.now()
        );
    }

    @Test
    void testGetYearlySumOfSalaries() {
        Map<Integer, Double> yearlySums = Map.of(2025, 50000.0);
        when(salaryService.getYearlySumOfSalaries()).thenReturn(yearlySums);

        ResponseEntity<Map<Integer, Double>> response = salaryController.getYearlySumOfSalaries();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(yearlySums, response.getBody());
        verify(salaryService, times(1)).getYearlySumOfSalaries();
    }

    @Test
    void testGetSalariesByEmpId() {
        List<Salary> salaries = Arrays.asList(salary);
        when(salaryService.getSalariesByEmpID(1)).thenReturn(salaries);

        ResponseEntity<List<Salary>> response = salaryController.getSalariesByEmpId(1);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(salaries, response.getBody());
        verify(salaryService, times(1)).getSalariesByEmpID(1);
    }

    @Test
    void testGetAllSalaryEmployeeDetails() {
        List<SalaryDTO> salaryEmployeeDetails = Arrays.asList(salaryDTO);
        when(salaryService.getAllSalaryEmployeeDetails()).thenReturn(salaryEmployeeDetails);

        ResponseEntity<List<SalaryDTO>> response = salaryController.getAllSalaryEmployeeDetails();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(salaryEmployeeDetails, response.getBody());
        verify(salaryService, times(1)).getAllSalaryEmployeeDetails();
    }

    @Test
    void testCalculateSalary() {
        doNothing().when(salaryCalculationService).calculateAndStoreSalary(request.getMonthYear());

        ResponseEntity<CustomResponse> response = salaryController.calculateSalary(request);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Salaries calculated and stored successfully", response.getBody().getMessage());
        verify(salaryCalculationService, times(1)).calculateAndStoreSalary(request.getMonthYear());
    }
}