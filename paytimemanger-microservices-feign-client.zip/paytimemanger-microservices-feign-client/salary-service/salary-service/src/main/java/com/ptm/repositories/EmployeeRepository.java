package com.ptm.repositories;

import com.ptm.models.Employee;
import com.ptm.models.PayRate;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
    Optional<Employee> findByEmpId(int empId);
    Optional<Employee> findByEmpEmail(String email);


    boolean existsByEmpId(int empId);
    boolean existsByEmpEmail(String email);
    List<Employee> findByEmpRoleNot(String role);
}
