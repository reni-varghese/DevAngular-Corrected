package com.ptm.services;

import com.ptm.dto.responses.SalaryDTO;
import com.ptm.models.Salary;

import java.util.List;
import java.util.Map;

public interface SalaryService {
    //admin-dashboard
    Map<Integer, Double> getYearlySumOfSalaries();
    //employee_earnings-overview
    List<Salary> getSalariesByEmpID(int empId);
    //new-payroll
    List<SalaryDTO> getAllSalaryEmployeeDetails();

}
