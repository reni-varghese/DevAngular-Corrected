package com.ptm.models;

import jakarta.persistence.*;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Past;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import jakarta.validation.constraints.Pattern;

import java.sql.Date;
import java.sql.Timestamp;


@Entity
@Table(name = "employee_details")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Employee {

    @Id
    @Column(name = "EMP_ID")
    private int empId;

    @Pattern(regexp = "^[A-Za-z ]+$", message = "Name must contain only letters and spaces")
    @Column(name = "EMP_NAME", nullable = false)
    private String empName;

    @Email(message = "Email should be valid")
    @Column(name = "EMP_EMAIL", nullable = false, unique = true)
    private String empEmail;

    @Past(message = "Date of Birth must be in the past")
    @Column(name = "EMP_DOB", nullable = false)
    private Date empDob;

    @Pattern(regexp = "(A\\+|A\\-|B\\+|B\\-|AB\\+|AB\\-|O\\+|O\\-)", message = "Blood group must be one of A+, A-, B+, B-, AB+, AB-, O+, O-")
    @Column(name = "EMP_BLOODGROUP", nullable = false)
    private String empBloodGroup;

    @Pattern(regexp = "(Male|Female|Other)", message = "Gender must be Male, Female, or Other")
    @Column(name = "EMP_GENDER", nullable = false)
    private String empGender;

    @Pattern(regexp = "(Single|Married|Divorced|Widowed)", message = "Marital status must be Single, Married, Divorced, or Widowed")
    @Column(name = "EMP_MARITALSTATUS", nullable = false)
    private String empMaritalStatus;

    @Pattern(regexp = "^[0-9]{12}$", message = "National ID must be 12 digits")
    @Column(name = "EMP_NATIONAL_ID", nullable = false, unique = true)
    private String empNationalId;

    @Pattern(regexp = "^[0-9]{10}$", message = "Phone number must be 10 digits")
    @Column(name = "EMP_PHONENO", nullable = false)
    private String empPhoneNo;


    @Column(name = "EMP_ROLE", nullable = false)
    private String empRole;

    @Column(name = "EMP_ACTIVE", nullable = false)
    private boolean empActive=true;

    @Column(name = "EMP_ISPAYROLL", nullable = false)
    private boolean empIsPayroll = false;

    @Column(name = "EMP_PAYROLLMANAGER")
    private Integer empPayrollManager;

    @Column(name = "EMP_CREATED_AT", nullable = false, updatable = false)
    private Timestamp empCreatedAt;

    @Column(name = "EMP_UPDATED_AT", nullable = false)
    private Timestamp empUpdatedAt;

    @Pattern(regexp = "^[A-Za-z ]+$", message = "Bank name must contain only letters and spaces")
    @Column(name = "BANK_NAME")
    private String bankName;

    @Pattern(regexp = "^[A-Za-z ]+$", message = "Account holder name must contain only letters and spaces")
    @Column(name = "ACCOUNT_HOLDER_NAME")
    private String accountHolderName;

    @Pattern(regexp = "^[0-9]{9,20}$", message = "Account number must be between 9 and 20 digits")
    @Column(name = "ACCOUNT_NUMBER")
    private String accountNumber;

    @Column(name = "IFSC_CODE")
    private String ifscCode;

    @Column(name = "BRANCH")
    private String branch;

    @Column(name = "password")
    private String password;

    @Column(name = "EMP_ISADMIN")
    private boolean empIsAdmin = false;

    @PrePersist
    protected void onCreate() {
        empCreatedAt = new Timestamp(System.currentTimeMillis());
    }

    @PreUpdate
    protected void onUpdate() {
        empUpdatedAt = new Timestamp(System.currentTimeMillis());
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public @Pattern(regexp = "^[A-Za-z ]+$", message = "Name must contain only letters and spaces") String getEmpName() {
        return empName;
    }

    public void setEmpName(@Pattern(regexp = "^[A-Za-z ]+$", message = "Name must contain only letters and spaces") String empName) {
        this.empName = empName;
    }

    public @Email(message = "Email should be valid") String getEmpEmail() {
        return empEmail;
    }

    public void setEmpEmail(@Email(message = "Email should be valid") String empEmail) {
        this.empEmail = empEmail;
    }

    public @Past(message = "Date of Birth must be in the past") Date getEmpDob() {
        return empDob;
    }

    public void setEmpDob(@Past(message = "Date of Birth must be in the past") Date empDob) {
        this.empDob = empDob;
    }

    public @Pattern(regexp = "(A\\+|A\\-|B\\+|B\\-|AB\\+|AB\\-|O\\+|O\\-)", message = "Blood group must be one of A+, A-, B+, B-, AB+, AB-, O+, O-") String getEmpBloodGroup() {
        return empBloodGroup;
    }

    public void setEmpBloodGroup(@Pattern(regexp = "(A\\+|A\\-|B\\+|B\\-|AB\\+|AB\\-|O\\+|O\\-)", message = "Blood group must be one of A+, A-, B+, B-, AB+, AB-, O+, O-") String empBloodGroup) {
        this.empBloodGroup = empBloodGroup;
    }

    public @Pattern(regexp = "(Male|Female|Other)", message = "Gender must be Male, Female, or Other") String getEmpGender() {
        return empGender;
    }

    public void setEmpGender(@Pattern(regexp = "(Male|Female|Other)", message = "Gender must be Male, Female, or Other") String empGender) {
        this.empGender = empGender;
    }

    public @Pattern(regexp = "(Single|Married|Divorced|Widowed)", message = "Marital status must be Single, Married, Divorced, or Widowed") String getEmpMaritalStatus() {
        return empMaritalStatus;
    }

    public void setEmpMaritalStatus(@Pattern(regexp = "(Single|Married|Divorced|Widowed)", message = "Marital status must be Single, Married, Divorced, or Widowed") String empMaritalStatus) {
        this.empMaritalStatus = empMaritalStatus;
    }

    public @Pattern(regexp = "^[0-9]{12}$", message = "National ID must be 12 digits") String getEmpNationalId() {
        return empNationalId;
    }

    public void setEmpNationalId(@Pattern(regexp = "^[0-9]{12}$", message = "National ID must be 12 digits") String empNationalId) {
        this.empNationalId = empNationalId;
    }

    public @Pattern(regexp = "^[0-9]{10}$", message = "Phone number must be 10 digits") String getEmpPhoneNo() {
        return empPhoneNo;
    }

    public void setEmpPhoneNo(@Pattern(regexp = "^[0-9]{10}$", message = "Phone number must be 10 digits") String empPhoneNo) {
        this.empPhoneNo = empPhoneNo;
    }



    public boolean isEmpActive() {
        return empActive;
    }

    public void setEmpActive(boolean empActive) {
        this.empActive = empActive;
    }

    public boolean isEmpIsPayroll() {
        return empIsPayroll;
    }

    public void setEmpIsPayroll(boolean empIsPayroll) {
        this.empIsPayroll = empIsPayroll;
    }

    public Integer getEmpPayrollManager() {
        return empPayrollManager;
    }

    public void setEmpPayrollManager(Integer empPayrollManager) {
        this.empPayrollManager = empPayrollManager;
    }

    public Timestamp getEmpCreatedAt() {
        return empCreatedAt;
    }

    public void setEmpCreatedAt(Timestamp empCreatedAt) {
        this.empCreatedAt = empCreatedAt;
    }

    public Timestamp getEmpUpdatedAt() {
        return empUpdatedAt;
    }

    public void setEmpUpdatedAt(Timestamp empUpdatedAt) {
        this.empUpdatedAt = empUpdatedAt;
    }

    public @Pattern(regexp = "^[A-Za-z ]+$", message = "Bank name must contain only letters and spaces") String getBankName() {
        return bankName;
    }

    public void setBankName(@Pattern(regexp = "^[A-Za-z ]+$", message = "Bank name must contain only letters and spaces") String bankName) {
        this.bankName = bankName;
    }

    public @Pattern(regexp = "^[A-Za-z ]+$", message = "Account holder name must contain only letters and spaces") String getAccountHolderName() {
        return accountHolderName;
    }

    public void setAccountHolderName(@Pattern(regexp = "^[A-Za-z ]+$", message = "Account holder name must contain only letters and spaces") String accountHolderName) {
        this.accountHolderName = accountHolderName;
    }

    public @Pattern(regexp = "^[0-9]{9,20}$", message = "Account number must be between 9 and 20 digits") String getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(@Pattern(regexp = "^[0-9]{9,20}$", message = "Account number must be between 9 and 20 digits") String accountNumber) {
        this.accountNumber = accountNumber;
    }

    public String getIfscCode() {
        return ifscCode;
    }

    public void setIfscCode(String ifscCode) {
        this.ifscCode = ifscCode;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isEmpIsAdmin() {
        return empIsAdmin;
    }

    public void setEmpIsAdmin(boolean empIsAdmin) {
        this.empIsAdmin = empIsAdmin;
    }
}