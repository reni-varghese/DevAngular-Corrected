package com.ptm.services.impl;

import com.ptm.client.*;
import com.ptm.dto.*;
import com.ptm.exceptions.PayRateNotFoundException;
import com.ptm.exceptions.ServiceUnavailableException;
import com.ptm.models.Salary;
import com.ptm.repositories.SalaryRepository;
import com.ptm.services.ISalaryCalculationService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.YearMonth;
import java.util.List;

@AllArgsConstructor
@Service
@Slf4j
public class SalaryCalculationServiceImpl implements ISalaryCalculationService {

    private final WeeklyTimeSheetClient weeklyTimeSheetClient;
    private final CashClaimsAndAllowanceClient cashClaimsAndAllowanceClient;
    private final PayRateClient payRateClient;
    private final EmployeeRoleClient employeeClient;
    private final SalaryRepository salaryRepository;

    @Override
    public void calculateAndStoreSalary(YearMonth monthYear) {
        log.info("Starting salary calculation for the month: {}", monthYear);

        // Fetch all employees
        List<EmployeeDTO> employees;
        try {
            employees = employeeClient.findByEmpRoleNot("Admin");
        } catch (Exception e) {
            log.error("Failed to fetch employees", e);
            throw new ServiceUnavailableException("Failed to fetch employees", e);
        }

        for (EmployeeDTO employee : employees) {
            int empId = employee.getEmpId();
            System.out.println(empId);

            // Fetch timesheets
            List<WeeklyTimeSheetDTO> approvedTimesheets;
            try {
                approvedTimesheets = weeklyTimeSheetClient.findByEmpIdAndStatus(empId, "Approved");
            } catch (Exception e) {
                log.error("Failed to fetch timesheets for employee ID: {}", empId, e);
                throw new ServiceUnavailableException("Failed to fetch timesheets for employee ID: " + empId, e);
            }

            List<WeeklyTimeSheetDTO> filteredTimesheets = approvedTimesheets.stream()
                    .filter(ts -> YearMonth.from(ts.getWeekStart()).equals(monthYear))
                    .toList();

            if (filteredTimesheets.isEmpty()) {
                log.info("No approved timesheets found for employee ID: {} for the month: {}", empId, monthYear);
                continue; // Skip if no approved timesheets found for the employee
            }

            // Sum total hours
            double totalHours = filteredTimesheets.stream().mapToDouble(WeeklyTimeSheetDTO::getTotalHours).sum();

            // Fetch claims
            List<CashClaimsAndAllowanceDTO> claims;
            try {
                claims = cashClaimsAndAllowanceClient.findByEmpId(empId);
            } catch (Exception e) {
                log.error("Failed to fetch claims for employee ID: {}", empId, e);
                throw new ServiceUnavailableException("Failed to fetch claims for employee ID: " + empId, e);
            }

            List<CashClaimsAndAllowanceDTO> filteredClaims = claims.stream()
                    .filter(claim -> YearMonth.from(claim.getDateOfClaim()).equals(monthYear))
                    .toList();

            // Sum claims amount
            double totalClaimsAmount = filteredClaims.stream().mapToDouble(CashClaimsAndAllowanceDTO::getAmount).sum();

            PayRateDTO payRate;
            try {
                payRate = payRateClient.findByEmpRole(employee.getEmpRole())
                        .orElseThrow(() -> new PayRateNotFoundException("PayRate not found for employee role: " + employee.getEmpRole()));
            } catch (Exception e) {
                log.error("Failed to fetch pay rate for employee role: {}", employee.getEmpRole(), e);
                throw new ServiceUnavailableException("Failed to fetch pay rate for employee role: " + employee.getEmpRole(), e);
            }

            // Calculate basic pay and net pay
            double basicPay = totalHours * payRate.getBasicPay();
            double pf = payRate.getPf(); // PF deduction
            double deductions = pf; // Assuming only PF as a deduction for simplicity
            double netPay = basicPay + totalClaimsAmount - deductions;

            // Ensure all required fields are populated
            Salary salary = new Salary();
            salary.setEmpId(empId);
            salary.setMonthYear(monthYear.atDay(1)); // Storing only the month year
            salary.setBasicPay(basicPay);
            salary.setClaims(totalClaimsAmount);
            salary.setDeductions(deductions);
            salary.setNetPay(netPay);
            salary.setPayrollProcessedDate(LocalDate.now());

            salaryRepository.save(salary);
            log.info("Salary calculated for employee ID: {} for the month: {}", empId, monthYear);
        }

        log.info("Salary calculation completed for the month: {}", monthYear);
    }
}