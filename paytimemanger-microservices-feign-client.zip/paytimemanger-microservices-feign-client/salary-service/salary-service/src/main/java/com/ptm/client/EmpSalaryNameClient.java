package com.ptm.client;


import com.ptm.dto.EmployeeNameDTO;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

@FeignClient(name = "employee-service")
public interface EmpSalaryNameClient {
    @GetMapping("/api/employees/name/{empId}")
    @CircuitBreaker(name = "employeeService", fallbackMethod = "fallbackGetEmployeeName")
    ResponseEntity<EmployeeNameDTO> getEmployeeName(@PathVariable int empId);

    default ResponseEntity<EmployeeNameDTO> fallbackGetEmployeeName(int empId, Throwable throwable) {
        // Fallback logic
        return ResponseEntity.status(HttpStatus.SERVICE_UNAVAILABLE).build();
    }
}
