package com.ptm.services;

import com.ptm.models.Salary;

import java.time.YearMonth;

public interface ISalaryCalculationService {
    void calculateAndStoreSalary(YearMonth monthYear);

}