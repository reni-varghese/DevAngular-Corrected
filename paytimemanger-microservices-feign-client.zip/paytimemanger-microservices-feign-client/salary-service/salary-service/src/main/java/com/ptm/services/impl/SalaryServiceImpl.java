package com.ptm.services.impl;

import com.ptm.client.EmpSalaryNameClient;

import com.ptm.dto.EmployeeNameDTO;
import com.ptm.dto.responses.SalaryDTO;
import com.ptm.exceptions.EmployeeNotFoundException;
import com.ptm.models.Salary;
import com.ptm.repositories.SalaryRepository;
import com.ptm.services.SalaryService;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@AllArgsConstructor
@Service
@Slf4j
public class SalaryServiceImpl implements SalaryService {

    private final SalaryRepository salaryRepository;
    private final EmpSalaryNameClient employeeClient;

    @Override
    public Map<Integer, Double> getYearlySumOfSalaries() {
        log.info("Fetching yearly sum of salaries.");
        List<Object[]> results = salaryRepository.findYearlySumOfSalaries();
        Map<Integer, Double> yearlySums = new HashMap<>();
        for (Object[] result : results) {
            Integer year = (Integer) result[0];
            Double yearlySum = (Double) result[1];
            yearlySums.put(year, yearlySum);
        }
        log.info("Yearly sums of salaries fetched successfully.");
        return yearlySums;
    }

    @Override
    public List<Salary> getSalariesByEmpID(int empID) {
        log.info("Fetching salaries for employee ID: {}", empID);
        List<Salary> result = salaryRepository.findSalaryByEmpId(empID);
        if (result.isEmpty()) {
            log.error("Salary for Employee with id: {} is not available", empID);
            throw new EmployeeNotFoundException("Salary for Employee with id: " + empID + " is not available");
        }
        log.info("Salaries for employee ID: {} fetched successfully.", empID);
        return result;
    }

    @Override
    public List<SalaryDTO> getAllSalaryEmployeeDetails() {
        log.info("Fetching all salary employee details.");
        List<Salary> queryResults = salaryRepository.findAll();

        List<SalaryDTO> salaryEmployeeDTOList = queryResults.stream().map(result -> {
            ResponseEntity<EmployeeNameDTO> response = employeeClient.getEmployeeName(result.getEmpId());
            String empName = response.getBody().getEmpName();
            SalaryDTO dto = new SalaryDTO();
            dto.setSalaryId(result.getSalaryId());
            dto.setEmpId(result.getEmpId());
            dto.setEmpName(empName);
            dto.setMonthYear(result.getMonthYear());
            dto.setBasicpay(result.getBasicPay());
            dto.setClaims(result.getClaims());
            dto.setDeductions(result.getDeductions());
            dto.setNetpay(result.getNetPay());
            dto.setPayrollProcessedDate(result.getPayrollProcessedDate());
            return dto;
        }).collect(Collectors.toList());

        log.info("All salary employee details fetched successfully.");
        return salaryEmployeeDTOList;
    }
}
