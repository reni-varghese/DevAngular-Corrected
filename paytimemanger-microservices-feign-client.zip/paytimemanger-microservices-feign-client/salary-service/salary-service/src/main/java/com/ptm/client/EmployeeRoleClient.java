package com.ptm.client;

import com.ptm.dto.EmployeeDTO;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Collections;
import java.util.List;

@FeignClient(name = "employee-service")
public interface EmployeeRoleClient {
    @GetMapping("/api/employees/salary-employees")
    @CircuitBreaker(name = "employeeService", fallbackMethod = "fallbackFindByEmpRoleNot")
    List<EmployeeDTO> findByEmpRoleNot(@RequestParam String empRole);

    default List<EmployeeDTO> fallbackFindByEmpRoleNot(String empRole, Throwable throwable) {
        // Fallback logic
        return Collections.emptyList();
    }
}
