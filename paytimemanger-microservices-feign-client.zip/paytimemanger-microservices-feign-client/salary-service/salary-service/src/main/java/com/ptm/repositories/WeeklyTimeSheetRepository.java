package com.ptm.repositories;

import com.ptm.models.WeeklyTimeSheet;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface WeeklyTimeSheetRepository extends JpaRepository<WeeklyTimeSheet, Integer> {
    List<WeeklyTimeSheet> findByEmpIdAndStatus(int empId, String status);
    boolean existsByEmpId(int empId);
    @Query("From WeeklyTimeSheet w where w.status=:status")
    List<WeeklyTimeSheet> getByStatus(@Param("status") String status);
    @Query("from WeeklyTimeSheet w where w.empId=:empId and w.weekStart=:weekStart")
    Optional<WeeklyTimeSheet> findByEmpIdAndWeekStartDate(@Param("empId") int empId, @Param("weekStart") LocalDate weekStart);
}
