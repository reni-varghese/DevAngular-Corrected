package com.ptm.dto;

import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;
@Getter
@Setter
public class CashClaimsAndAllowanceDTO {
    private int claimId;
    private int empId;
    private String empName;
    private LocalDate dateOfClaim;
    private String description;
    private byte[] attachment;
    private double amount;
    private String remark;
    private LocalDate dateOfAction;
    private String allowanceType;


}
