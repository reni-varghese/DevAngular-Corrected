package com.ptm.client;


import com.ptm.dto.CashClaimsAndAllowanceDTO;
import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Collections;
import java.util.List;

@FeignClient(name = "claim-service")
public interface CashClaimsAndAllowanceClient {
    @GetMapping("/api/claims/salary-claims")
    @CircuitBreaker(name = "claimService", fallbackMethod = "fallbackFindByEmpId")
    List<CashClaimsAndAllowanceDTO> findByEmpId(@RequestParam int empId);

    default List<CashClaimsAndAllowanceDTO> fallbackFindByEmpId(int empId, Throwable throwable) {
        // Fallback logic
        return Collections.emptyList();
    }
}
