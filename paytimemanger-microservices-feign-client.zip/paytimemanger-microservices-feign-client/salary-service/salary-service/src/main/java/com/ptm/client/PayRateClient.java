package com.ptm.client;

import com.ptm.dto.PayRateDTO;

import io.github.resilience4j.circuitbreaker.annotation.CircuitBreaker;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Optional;
@FeignClient(name = "payrate-service")
public interface PayRateClient {
    @GetMapping("/api/payrate/salary-payrate")
    @CircuitBreaker(name = "payrateService", fallbackMethod = "fallbackFindByEmpRole")
    Optional<PayRateDTO> findByEmpRole(@RequestParam String empRole);

    default Optional<PayRateDTO> fallbackFindByEmpRole(String empRole, Throwable throwable) {
        // Fallback logic
        return Optional.empty();
    }
}
