package com.ptm.repositories;

import com.ptm.models.EmployeeQuery;
import org.springframework.data.jpa.repository.JpaRepository;


public interface EmployeeQueryRepository extends JpaRepository<EmployeeQuery, Integer> {



}
