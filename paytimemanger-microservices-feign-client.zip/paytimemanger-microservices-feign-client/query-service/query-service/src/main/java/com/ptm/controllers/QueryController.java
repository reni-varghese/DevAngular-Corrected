package com.ptm.controllers;

import com.ptm.dto.requests.EmployeeQueryDTO;
import com.ptm.dto.responses.CustomResponse;
import com.ptm.dto.responses.PayrollQueryDTO;
import com.ptm.services.EmployeeQueryService;
import com.ptm.services.PayrollQueryService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/query")
@RequiredArgsConstructor
@Slf4j
public class QueryController {

    private final EmployeeQueryService employeeQueryService;
    private final PayrollQueryService payrollQueryService;

    // Employee Query Endpoints
    @PostMapping("/employee")
    public ResponseEntity<CustomResponse> submitEmployeeQuery(@RequestBody EmployeeQueryDTO employeeQueryDTO) {
        log.info("Submitting new employee query: {}", employeeQueryDTO);
        employeeQueryService.submitQuery(employeeQueryDTO);
        CustomResponse customResponse = new CustomResponse(HttpStatus.OK.value(), "Employee query submitted successfully!", LocalDateTime.now());
        log.info("Employee query submitted successfully.");
        return ResponseEntity.ok(customResponse);
    }

    @GetMapping("/employee")
    public ResponseEntity<List<EmployeeQueryDTO>> retrieveEmployeeQueries() {
        log.info("Retrieving all employee queries.");
        List<EmployeeQueryDTO> queries = employeeQueryService.retrieveQueries();
        log.info("Employee queries retrieved: {}", queries);
        return ResponseEntity.ok(queries);
    }

    @GetMapping("/employee/{queryId}")
    public ResponseEntity<EmployeeQueryDTO> getEmployeeQueryById(@PathVariable int queryId) {
        log.info("Retrieving employee query by ID: {}", queryId);
        EmployeeQueryDTO query = employeeQueryService.getById(queryId);
        log.info("Employee query retrieved: {}", query);
        return ResponseEntity.ok(query);
    }

    @PatchMapping("/employee/{queryId}")
    public ResponseEntity<CustomResponse> updateEmployeeQuery(@PathVariable int queryId, @RequestBody EmployeeQueryDTO employeeQueryDTO) {
        log.info("Updating employee query ID: {}", queryId);
        employeeQueryService.updateQuery(queryId, employeeQueryDTO);
        CustomResponse customResponse = new CustomResponse(HttpStatus.OK.value(), "Employee query updated successfully!", LocalDateTime.now());
        log.info("Employee query updated successfully.");
        return ResponseEntity.ok(customResponse);
    }

    // Payroll Query Endpoints
    @GetMapping("/payroll")
    public ResponseEntity<List<PayrollQueryDTO>> retrievePayrollQueries() {
        log.info("Retrieving all payroll queries.");
        List<PayrollQueryDTO> queries = payrollQueryService.retrieveQueries();
        log.info("Payroll queries retrieved: {}", queries);
        return ResponseEntity.ok(queries);
    }

    @GetMapping("/payroll/{queryId}")
    public ResponseEntity<PayrollQueryDTO> getPayrollQueryById(@PathVariable int queryId) {
        log.info("Retrieving payroll query by ID: {}", queryId);
        PayrollQueryDTO query = payrollQueryService.getById(queryId);
        log.info("Payroll query retrieved: {}", query);
        return ResponseEntity.ok(query);
    }

    @PatchMapping("/payroll/{queryId}")
    public ResponseEntity<CustomResponse> updatePayrollQuery(@PathVariable int queryId, @RequestBody PayrollQueryDTO payrollQueryDTO) {
        log.info("Updating payroll query ID: {}", queryId);
        payrollQueryService.updatePayrollQuery(queryId, payrollQueryDTO);
        CustomResponse customResponse = new CustomResponse(HttpStatus.OK.value(), "Payroll query updated successfully!", LocalDateTime.now());
        log.info("Payroll query ID: {} updated successfully.", queryId);
        return ResponseEntity.ok(customResponse);
    }
}