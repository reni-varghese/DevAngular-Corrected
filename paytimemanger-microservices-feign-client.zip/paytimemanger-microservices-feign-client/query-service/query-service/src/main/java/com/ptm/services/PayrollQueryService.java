package com.ptm.services;

import com.ptm.dto.responses.PayrollQueryDTO;

import java.util.List;

public interface PayrollQueryService {

    List<PayrollQueryDTO> retrieveQueries();
    PayrollQueryDTO getById(int queryId);
    void updatePayrollQuery(int queryId, PayrollQueryDTO payrollQueryDTO);
}