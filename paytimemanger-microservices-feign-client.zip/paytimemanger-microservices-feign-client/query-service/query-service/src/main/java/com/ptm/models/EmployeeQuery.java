package com.ptm.models;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

@Entity
@Table(name = "Employee_Queries")
@Getter
@Setter
public class EmployeeQuery {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "query_id")
    private int queryId;

    @Column(name="category")
    private String category;
    @Column(name="date_of_closed")
    private Date dateOfClosed;
    @Column(name="date_of_created")
    private Date dateOfCreated;
    @Column(name="description")
    private String description;
    @Column(name = "emp_id")
    private int empId;
    @Column(name="feedback")
    private String feedback;
    @Column(name="status")
    private String status;

    @Transient
    private String empName;

}