package com.ptm.exceptions;

public class QueryNotFoundException extends RuntimeException {
    public QueryNotFoundException() {
    }

    public QueryNotFoundException(String message) {
        super(message);
    }
}