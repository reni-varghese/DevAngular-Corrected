package com.ptm.dto.responses;

import lombok.Getter;
import lombok.Setter;

import java.util.Date;
@Getter
@Setter
public class PayrollQueryDTO {
    private int queryId;
    private String category;
    private Date dateOfClosed;
    private Date dateOfCreated;
    private String description;
    private int empId;
    private String feedback;
    private String status;
    private String empName;
}