package com.ptm.controllers;

import com.ptm.controllers.QueryController;
import com.ptm.dto.requests.EmployeeQueryDTO;
import com.ptm.dto.responses.CustomResponse;
import com.ptm.dto.responses.PayrollQueryDTO;
import com.ptm.models.EmployeeQuery;
import com.ptm.services.EmployeeQueryService;
import com.ptm.services.PayrollQueryService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class QueryControllerTest {

    @Mock
    private EmployeeQueryService employeeQueryService;

    @Mock
    private PayrollQueryService payrollQueryService;

    @InjectMocks
    private QueryController queryController;

    private EmployeeQueryDTO employeeQueryDTO;
    private PayrollQueryDTO payrollQueryDTO;
    private EmployeeQuery employeeQuery;
    private CustomResponse customResponse;

    @BeforeEach
    void setUp() {
        employeeQueryDTO = new EmployeeQueryDTO();
        payrollQueryDTO = new PayrollQueryDTO();
        employeeQuery = new EmployeeQuery();
        customResponse = new CustomResponse(HttpStatus.OK.value(), "Query updated successfully!", LocalDateTime.now());
    }

    // Employee Query Tests
    @Test
    void testSubmitEmployeeQuery() {
        doNothing().when(employeeQueryService).submitQuery(employeeQueryDTO);

        ResponseEntity<CustomResponse> response = queryController.submitEmployeeQuery(employeeQueryDTO);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Employee query submitted successfully!", response.getBody().getMessage());
        verify(employeeQueryService, times(1)).submitQuery(employeeQueryDTO);
    }

    @Test
    void testRetrieveEmployeeQueries() {
        List<EmployeeQueryDTO> queries = Arrays.asList(employeeQueryDTO);
        when(employeeQueryService.retrieveQueries()).thenReturn(queries);

        ResponseEntity<List<EmployeeQueryDTO>> response = queryController.retrieveEmployeeQueries();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(queries, response.getBody());
        verify(employeeQueryService, times(1)).retrieveQueries();
    }

    @Test
    void testGetEmployeeQueryById() {
        when(employeeQueryService.getById(1)).thenReturn(employeeQueryDTO);

        ResponseEntity<EmployeeQueryDTO> response = queryController.getEmployeeQueryById(1);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(employeeQueryDTO, response.getBody());
        verify(employeeQueryService, times(1)).getById(1);
    }

    @Test
    void testUpdateEmployeeQuery() {
        doNothing().when(employeeQueryService).updateQuery(1, employeeQueryDTO);

        ResponseEntity<CustomResponse> response = queryController.updateEmployeeQuery(1, employeeQueryDTO);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Employee query updated successfully!", response.getBody().getMessage());
        verify(employeeQueryService, times(1)).updateQuery(1, employeeQueryDTO);
    }

    // Payroll Query Tests
    @Test
    void testRetrievePayrollQueries() {
        List<PayrollQueryDTO> queries = Arrays.asList(payrollQueryDTO);
        when(payrollQueryService.retrieveQueries()).thenReturn(queries);

        ResponseEntity<List<PayrollQueryDTO>> response = queryController.retrievePayrollQueries();

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(queries, response.getBody());
        verify(payrollQueryService, times(1)).retrieveQueries();
    }

    @Test
    void testGetPayrollQueryById() {
        when(payrollQueryService.getById(1)).thenReturn(payrollQueryDTO);

        ResponseEntity<PayrollQueryDTO> response = queryController.getPayrollQueryById(1);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals(payrollQueryDTO, response.getBody());
        verify(payrollQueryService, times(1)).getById(1);
    }

    @Test
    void testUpdatePayrollQuery() {
        doNothing().when(payrollQueryService).updatePayrollQuery(1, payrollQueryDTO);

        ResponseEntity<CustomResponse> response = queryController.updatePayrollQuery(1, payrollQueryDTO);

        assertEquals(HttpStatus.OK, response.getStatusCode());
        assertEquals("Payroll query updated successfully!", response.getBody().getMessage());
        verify(payrollQueryService, times(1)).updatePayrollQuery(1, payrollQueryDTO);
    }
}

